#pragma once
#include <iostream>
#include <string>


class Book
{
private:
	char title[50];
	char author[50];
	int yearOfIssue;
	double price;
	int numberOfPages;
	void calculatePrice();
	
public:
	Book();
	void input();
	void output() const;
	int getPages() const { return numberOfPages; }
	double getPrice() const { return price; }
};

