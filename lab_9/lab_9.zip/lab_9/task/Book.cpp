#include <iostream>
#include "Book.h"
using namespace std;
void Book::calculatePrice()
{
	double pageCost;
	if (numberOfPages < 100) pageCost = 1.0;
	if (numberOfPages > 300) pageCost = 0.8;
	else pageCost = 0.9;
	price = (numberOfPages * pageCost) + 25;
}
Book::Book()
{
	char title[50] = " ";
	char author[50] = " ";
    yearOfIssue = 0;
    numberOfPages = 0;
    price = 0.0;
}

void Book::input()
{
    cout << "Enter book title: ";
	cin.ignore();
	cin.getline(title, 50);
	cout << "Enter author's name: ";
	cin.getline(author, 50);
	cout << "Enter year of issue: ";
	cin >> yearOfIssue;
	cout << "Enter number of pages: ";
	cin >> numberOfPages;
	calculatePrice();
}

void Book::output() const
{
	cout << "Title: " << title << endl;
	cout << "Author: " << author << endl;
	cout << "Year of issue: " << yearOfIssue << endl;
	cout << "Number of pages: " << numberOfPages << endl;
	cout << "Price: " << price << endl;
}
